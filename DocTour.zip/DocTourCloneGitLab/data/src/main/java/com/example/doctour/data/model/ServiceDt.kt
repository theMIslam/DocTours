package com.example.doctour.data.model

import com.example.doctour.data.utils.DataMapper
import com.example.doctour.domain.model.Service
data class ServiceDt(
    val description: String?,
    val id: String,
    val name: String?,
    val slug:String?,
    val price: Int?,
    val subservice_service: List<SubServiceDt>?= emptyList()
):DataMapper<Service>{
    override fun mapToDomain()= Service(
       description,
        id,
        name,
        slug=slug,
        price,
        subservice_service?.map { it.mapToDomain() }
    )
}
