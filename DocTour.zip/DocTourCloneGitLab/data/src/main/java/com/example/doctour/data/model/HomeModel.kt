package com.example.doctour.data.model

data class HomeModel(
    val title: String?,
    val image: Int?
)
