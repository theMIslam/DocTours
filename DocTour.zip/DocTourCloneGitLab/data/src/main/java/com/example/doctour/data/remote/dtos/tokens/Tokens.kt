package com.example.doctour.data.remote.dtos.tokens

class Tokens(
    val accessToken: String,
    val refreshToken: String
)

class RefreshToken(
    val refreshToken: String
)