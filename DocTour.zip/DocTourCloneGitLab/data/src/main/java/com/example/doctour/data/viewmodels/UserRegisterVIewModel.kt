package com.example.doctour.data.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.doctour.data.local.db.entities.doctour.UserRegisterEntity
import com.example.doctour.data.remote.apiservices.UserRegisterApiService
import com.example.doctour.data.remote.client.RetrofitClient

class UserRegisterVIewModel: ViewModel(){

//    private val apiService: UserRegisterApiService by lazy {
//        RetrofitClient.create()
//    }

    
}