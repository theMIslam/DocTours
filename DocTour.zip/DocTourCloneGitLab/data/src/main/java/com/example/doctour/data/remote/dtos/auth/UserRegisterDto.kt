package com.example.doctour.data.remote.dtos.auth

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
class UserRegisterDto {
}