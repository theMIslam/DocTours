package com.example.doctour.domain.model

data class City(
    val id:String,
    val name:String?
)
