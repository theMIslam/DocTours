package com.example.doctour.domain.model.local

class DoctourLocal(
    val id: Long,
    val bar: String
)