package com.example.doctour.domain.model

class UserRegister(
    val phone_number: String?,
    val fullname: String?,
    val gender: String?,
    val birthday: String?,
    val password: String?
)