package com.example.doctour.domain.model

data class UserConfim(
    val user_id:Int,
    val code:Int
)
