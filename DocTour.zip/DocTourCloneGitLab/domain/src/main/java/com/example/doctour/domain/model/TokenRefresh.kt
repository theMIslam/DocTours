package com.example.doctour.domain.model

data class TokenRefresh(
    val refresh:String?,
    val access:String?
)
