package com.example.doctour.domain.model

data class PasswordReset(
    val email:String?
)
