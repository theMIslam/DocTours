package com.example.doctour.domain.model

data class Speciality(
    val id: String,
    val name: String?
)
