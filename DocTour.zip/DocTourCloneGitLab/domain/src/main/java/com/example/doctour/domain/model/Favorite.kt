package com.example.doctour.domain.model

data class Favorite(
    val id:String,
    val user:Int?,
    val doctor:Int?
)