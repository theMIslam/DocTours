package com.example.doctour.domain.model

data class Specialization(
    val id:String,
    val title:String?,
    val doctor:Int?
)
