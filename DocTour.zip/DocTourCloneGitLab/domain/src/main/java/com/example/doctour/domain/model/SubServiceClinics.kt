package com.example.doctour.domain.model

data class SubServiceClinics(
    val clinics:List<Clinics>?= emptyList()
)
