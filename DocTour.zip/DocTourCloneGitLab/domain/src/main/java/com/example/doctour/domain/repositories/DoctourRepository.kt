package com.example.doctour.domain.repositories

import com.example.doctour.domain.model.local.DoctourLocal
import com.example.doctour.domain.utils.RemoteWrapper
import kotlinx.coroutines.flow.Flow

interface DoctourRepository {
    fun fetchDoctour(): RemoteWrapper<DoctourLocal>
    fun getDoctour(): Flow<List<DoctourLocal>>
}