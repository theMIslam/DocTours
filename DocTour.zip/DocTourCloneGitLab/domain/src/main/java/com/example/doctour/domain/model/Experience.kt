package com.example.doctour.domain.model

data class Experience(
    val id:String,
    val year:String?,
    val title:String?,
    val doctor:Int?
)
