package com.example.doctour.domain.model

data class UserLogin(
    val phone_number:String?,
    val password:String?
)
