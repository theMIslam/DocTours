package com.example.doctour.domain.model

data class Education(
    val id:String,
    val year:String?,
    val title:String?,
    val specialization:String?,
    val doctor:Int?
)
