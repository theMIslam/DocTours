package com.example.doctour.domain.model

data class Certificates(
    val id:Int,
    val year:String?,
    val title:String?,
    val doctor:Int?
)
