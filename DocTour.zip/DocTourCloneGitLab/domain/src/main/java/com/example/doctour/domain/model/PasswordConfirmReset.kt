package com.example.doctour.domain.model

data class PasswordConfirmReset(
    val password:String?
)
