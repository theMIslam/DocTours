import org.gradle.api.JavaVersion

object Options {
    val compileOptions = JavaVersion.VERSION_17
    const val kotlinOptions = "17"
}