# Doctour

```
cd existing_repo
git remote add origin https://gitlab.com/theMIslam/doctour.git
git branch -M main
git push -uf origin main
```

```
git pull origin dev
git push origin dev --force
git remote remove origin
git remote -v
git log
git push --help
git pull
git fetch origin
git stash
git status
```

```
git init
git add .
git commit -m "comment"
git remote add origin https://gitlab.com/theMIslam/doctour.git
git push origin main
```
