package com.example.doctour.presentation.ui.fragments.home.model

data class DoctorModel(
    val name: String?,
    val expirience: String?,
    val spesiality: String?,
    val work: String?,
    val stars: Int?,
    val rating: String?,
    val recommendation: String?,
    val location: Int?,
    val country: String?,
    val price: String?,
    val valuta: Int?
)
