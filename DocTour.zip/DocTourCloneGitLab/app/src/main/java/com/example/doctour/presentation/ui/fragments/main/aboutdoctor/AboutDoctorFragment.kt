package com.example.doctour.presentation.ui.fragments.main.aboutdoctor

import android.annotation.SuppressLint
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import by.kirich1409.viewbindingdelegate.viewBinding
import com.example.doctour.R
import com.example.doctour.base.BaseFragment
import com.example.doctour.databinding.FragmentAboutDoctorBinding
import com.example.doctour.presentation.extensions.loadImage
import com.example.doctour.presentation.extensions.showToast
import com.example.doctour.common.UIState
import com.example.doctour.presentation.model.DoctorUi
import com.example.doctour.presentation.model.ReviewUi
import com.example.doctour.presentation.ui.fragments.main.aboutdoctor.adapter.FeedbacksAdapter
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AboutDoctorFragment
    : BaseFragment<FragmentAboutDoctorBinding, AboutDoctorViewModel>(
    R.layout.fragment_about_doctor
) {

    override val binding: FragmentAboutDoctorBinding by viewBinding(FragmentAboutDoctorBinding::bind)
    override val viewModel: AboutDoctorViewModel by viewModels()
    private lateinit var adapterFeedback: FeedbacksAdapter
    private var selectedList = arrayListOf<DoctorUi>()
    private var reviewList = ArrayList<ReviewUi>()

    override fun initialize() {
        super.initialize()
        binding.rvFeedbacks.layoutManager=LinearLayoutManager(context)
        adapterFeedback=FeedbacksAdapter()
        binding.rvFeedbacks.adapter = adapterFeedback
        getInfoAboutDoctor()
    }

    override fun initSubscribers() {
        super.initSubscribers()
        viewModel.createFav.collectUIState(
            uiState = {
                binding.progressBar.isVisible = it is UIState.Loading
            },
            onSuccess = {
                viewModel.loading.postValue(false)
            }
        )
    }

    override fun initListeners() {
        super.initListeners()

        binding.tvArrowBack.setOnClickListener {
            findNavController().navigateUp()
        }
        binding.tvAllReviews.setOnClickListener {
            findNavController().navigate(R.id.aboutDoctorReviewFragment)
//                bundleOf( "listOfReview" to reviewList))
        }
        binding.btnRegister.setOnClickListener {
            findNavController().navigate(R.id.bookingToDoctorSecondFragment)
        }
        binding.checkboxHeart.setOnCheckedChangeListener { checkbox, isChecked ->
            if (isChecked) {
                showToast("Добавлено в избранные")
            } else {
                showToast("Удалено из избранных")
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun getInfoAboutDoctor() {
        if (arguments != null) {
            val data = this.arguments?.getSerializable("about") as DoctorUi
            binding.tvNameOfDoctor.text = "Врач ${data.full_name}"
            data.photo?.let { binding.image.loadImage(it) }
            binding.name.text = data.full_name
            // binding.tvSurgeon.text = data.specialties
            //binding.tvClinic.text = data.clinic
            binding.tvPrice.text = data.price.toString()
            binding.tvNumOfExperience.text = data.experience.toString()
            binding.tvNumOfRating.text = data.average_rating
            binding.tvNumOfFeedback.text = data.num_reviews
            binding.tvInfoAboutDoc.text = data.summary
            data.doctor_reviews?.let { adapterFeedback.addReview(it) }
           // data.doctor_reviews?.let { reviewList.addAll(it) }
        }

    }

}