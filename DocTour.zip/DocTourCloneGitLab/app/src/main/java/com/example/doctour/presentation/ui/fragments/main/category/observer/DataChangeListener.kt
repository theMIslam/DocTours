package com.example.doctour.presentation.ui.fragments.main.category.observer

interface DataChangeListener {
    fun updateText(newText: String)
}