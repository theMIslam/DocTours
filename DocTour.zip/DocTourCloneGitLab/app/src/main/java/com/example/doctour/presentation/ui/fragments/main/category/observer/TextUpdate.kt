package com.example.doctour.presentation.ui.fragments.main.category.observer

class TextUpdate (val newText: String)