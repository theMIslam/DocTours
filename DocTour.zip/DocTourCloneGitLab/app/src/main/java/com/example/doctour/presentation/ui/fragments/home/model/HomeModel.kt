package com.example.doctour.presentation.ui.fragments.home.model

data class HomeModel(
    val title: String?,
    val image: Int?
)
