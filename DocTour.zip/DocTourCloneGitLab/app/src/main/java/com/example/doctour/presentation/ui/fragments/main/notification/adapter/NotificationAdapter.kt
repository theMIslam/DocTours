package com.example.doctour.presentation.ui.fragments.main.notification.adapter

class NotificationAdapter {
}